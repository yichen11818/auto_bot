
 -- play_020-亲近
function leju_744e62498e985f9fce29be97a270c1c5()
	Play_AI_music("0:/music/020-亲近.mp3")
end

 -- play_9
function leju_71a4ac7e136494bbf6b40b6a3a2e3c66()
	Play_AI_music("0:/music/9.mp3")
end

 -- play_DL
function leju_5b62ce350f0dc8d52d4aa4cbc8b5462e()
	Play_AI_music("0:/music/DL.mp3")
end

 -- play_DPZC
function leju_26577aebdc327a285895caef104e3648()
	Play_AI_music("0:/music/DPZC.mp3")
end

 -- play_FW
function leju_57e36b8a3d5c5f350ffb5a104362ba73()
	Play_AI_music("0:/music/FW.mp3")
end

 -- play_hello_Ladies
function leju_23ce2bdbe06638820c7a03a275f89fc3()
	Play_AI_music("0:/music/hello_Ladies.mp3")
end

 -- play_hello_sir
function leju_ffa42ef8e2cc0dc09b726b5dde874644()
	Play_AI_music("0:/music/hello_sir.mp3")
end

 -- play_JG
function leju_6eab0b2bd3d6eec7b387df4d80a82339()
	Play_AI_music("0:/music/JG.mp3")
end

 -- play_lowbat
function leju_f68f30dfdf6c3a408a64f76ec18829f6()
	Play_AI_music("0:/music/lowbat.mp3")
end

 -- play_lowp
function leju_659a3fc5ceaf3777e5d7a75f4dc5b66f()
	Play_AI_music("0:/music/lowp.mp3")
end

 -- play_start
function leju_92d46ba37145851c7959dadee0c76854()
	Play_AI_music("0:/music/start.mp3")
end

 -- play_test1
function leju_920e043094aded50e16db2baa691dea7()
	Play_AI_music("0:/music/test1.mp3")
end

 -- play_tf卡丢失
function leju_02a613b34a84742ba9159e9d2c6bff6e()
	Play_AI_music("0:/music/tf卡丢失.mp3")
end

 -- play_zhangai
function leju_322a44069cef572e00155745e4b10a4e()
	Play_AI_music("0:/music/zhangai.mp3")
end

 -- play_zhehuole
function leju_af479c4b606313b6bda8b4e4e5f13bf0()
	Play_AI_music("0:/music/zhehuole.mp3")
end

 -- play_ZJSM
function leju_1d38aa08ab94c42933e7af15a03c4e82()
	Play_AI_music("0:/music/ZJSM.mp3")
end

 -- play_zouwaile
function leju_88187bcc3fdc9f1731568b1b35ff7018()
	Play_AI_music("0:/music/zouwaile.mp3")
end

 -- play_勃拉姆斯
function leju_2d5825e7ee90189a1b66bd963fa0bce2()
	Play_AI_music("0:/music/勃拉姆斯.mp3")
end

 -- play_江南style
function leju_bba9d788576f00d359d2ada5c503710d()
	Play_AI_music("0:/music/江南style.mp3")
end

 -- play_童年
function leju_05feaaea527bb317dafd26a8d98955e6()
	Play_AI_music("0:/music/童年.mp3")
end
