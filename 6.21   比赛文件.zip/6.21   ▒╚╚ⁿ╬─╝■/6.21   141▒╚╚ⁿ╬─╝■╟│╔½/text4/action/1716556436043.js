Blockly.Blocks['1716556436043'] = {
  init: function() {
    this.jsonInit({
      "type": "1716556436043",
      "message0": "3",
      "previousStatement": null,
      "nextStatement": null,
      "colour": "#EDC611",
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1716556436043'] = function(block) {
  let code = "MOTOrigid16(40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40)\nMOTOsetspeed(30)\nMOTOmove19(60,15,190,100,88,55,124,100,132,187,10,100,110,142,78,100,0,0,100)\nMOTOwait()\nMOTOsetspeed(40)\nMOTOmove19(60,15,190,99,95,55,130,98,132,187,10,105,120,145,85,108,0,0,100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(60,15,190,99,95,55,130,105,132,187,10,105,120,145,85,106,0,0,100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(60,15,190,100,88,55,124,105,132,187,10,100,105,132,85,106,0,0,100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(60,15,190,100,88,55,124,100,132,187,10,100,110,142,78,100,0,0,100)\nMOTOwait()\n";
  return code;
}

Blockly.Python['1716556436043'] = function(block) {
  let code = "base_action.action('3')\n";
  return code;
}

