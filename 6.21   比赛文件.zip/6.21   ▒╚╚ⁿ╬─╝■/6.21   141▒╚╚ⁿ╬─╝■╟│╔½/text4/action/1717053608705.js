Blockly.Blocks['1717053608705'] = {
  init: function() {
    this.jsonInit({
      "type": "1717053608705",
      "message0": "抱起箱子",
      "previousStatement": null,
      "nextStatement": null,
      "colour": '#C643F1',
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1717053608705'] = function(block) {
  let code = "MOTOsetspeed(30)\nMOTOrigid16(40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,0,0,0)\n\n\n-- 张\nMOTOsetspeed(35)\nMOTOmove19(80, 50, 149, 100, 93, 55, 124, 100, 120, 150, 50, 100, 107, 145, 76, 100, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(35)\nMOTOmove19(80, 50, 149, 100, 136, 150, 62, 100, 120, 150, 50, 100, 72, 50, 138, 100, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(10)\nMOTOmove19(80, 50, 149, 100, 149, 150, 58, 100, 120, 150, 50, 100, 52, 50, 142, 100, 0, 0, 100)\nMOTOwait()\n\n\n-- 2号15，10号180\nMOTOsetspeed(30)\nMOTOmove19(65, 15, 149, 100, 149, 150, 67, 100, 140, 180, 50, 100, 52, 50, 133, 100, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(25)\nMOTOmove19(65, 15, 149, 100, 104, 132, 70, 100, 140, 180, 50, 100, 93, 69, 130, 100, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(35)\nMOTOmove19(65, 15, 149, 100, 90, 55, 127, 100, 140, 180, 50, 100, 110, 145, 73, 100, 0, 0, 100)\nMOTOwait()\n";
  return code;
}

Blockly.Python['1717053608705'] = function(block) {
  let code = "base_action.action('抱起箱子')\n";
  return code;
}

