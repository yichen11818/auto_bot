Blockly.Blocks['1717056184633'] = {
  init: function() {
    this.jsonInit({
      "type": "1717056184633",
      "message0": "抱箱子右移2-1",
      "previousStatement": null,
      "nextStatement": null,
      "colour": '#C643F1',
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1717056184633'] = function(block) {
  let code = "MOTOsetspeed(30)\nMOTOrigid16(40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,0,0,0)\nMOTOsetspeed(60)\nMOTOmove19(65, 15, 149, 65, 90, 55, 127, 96, 140, 180, 50, 105, 110, 145, 73, 105, 0, 0, 100)\nMOTOwait()\nMOTOrigid16(40,40,40,70,70,70,70,70,40,40,40,70,70,70,70,70,0,0,0)\nMOTOsetspeed(80)\nMOTOmove19(65, 15, 149, 105, 90, 55, 127, 100, 140, 180, 50, 100, 110, 145, 73, 100, 0, 0, 100)\nMOTOwait()\nDelayMs(50)\n";
  return code;
}

Blockly.Python['1717056184633'] = function(block) {
  let code = "base_action.action('抱箱子右移2-1')\n";
  return code;
}

