Blockly.Blocks['1717056211483'] = {
  init: function() {
    this.jsonInit({
      "type": "1717056211483",
      "message0": "抱箱子左移2-4",
      "previousStatement": null,
      "nextStatement": null,
      "colour": '#C643F1',
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1717056211483'] = function(block) {
  let code = "MOTOsetspeed(30)\nMOTOrigid16(40,40,40,70,70,70,70,70,40,40,40,70,70,70,70,70,0,0,0)\nMOTOsetspeed(30)\nMOTOmove19(65, 15, 149, 100, 90, 55, 127, 93, 140, 180, 50, 135, 110, 145, 73, 100, 0, 0, 100)\nMOTOwait()\nMOTOrigid16(40,40,40,70,70,70,70,70,40,40,40,70,70,70,70,70,0,0,0)\nMOTOsetspeed(80)\nMOTOmove19(65, 15, 149, 100, 90, 55, 127, 100, 140, 180, 50, 95, 110, 145, 73, 100, 0, 0, 100)\nMOTOwait()\nDelayMs(260)\n";
  return code;
}

Blockly.Python['1717056211483'] = function(block) {
  let code = "base_action.action('抱箱子左移2-4')\n";
  return code;
}

