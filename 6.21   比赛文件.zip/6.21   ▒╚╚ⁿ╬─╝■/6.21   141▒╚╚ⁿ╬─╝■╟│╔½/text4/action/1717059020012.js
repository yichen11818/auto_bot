Blockly.Blocks['1717059020012'] = {
  init: function() {
    this.jsonInit({
      "type": "1717059020012",
      "message0": "抱箱左侧移1步",
      "previousStatement": null,
      "nextStatement": null,
      "colour": "#EDC611",
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1717059020012'] = function(block) {
  let code = "MOTOrigid16(40,40,40,70,70,70,70,70,40,40,40,70,70,70,70,70)\nMOTOsetspeed(30)\nMOTOmove19(60,15,190,100,90,55,127,93,132,187,20,135,110,145,73,100,0,0,100)\nMOTOwait()\nMOTOrigid16(40,40,40,70,70,70,70,70,40,40,40,70,70,70,70,70)\nMOTOsetspeed(80)\nMOTOmove19(60,15,190,100,90,55,127,100,132,187,20,95,110,145,73,100,0,0,100)\nMOTOwait()\nDelayMs(260)\n";
  return code;
}

Blockly.Python['1717059020012'] = function(block) {
  let code = "base_action.action('抱箱左侧移1步')\n";
  return code;
}

