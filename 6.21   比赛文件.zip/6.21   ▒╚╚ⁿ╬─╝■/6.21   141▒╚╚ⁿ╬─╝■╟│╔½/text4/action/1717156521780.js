Blockly.Blocks['1717156521780'] = {
  init: function() {
    this.jsonInit({
      "type": "1717156521780",
      "message0": "抱箱右转90度",
      "previousStatement": null,
      "nextStatement": null,
      "colour": "#EDC611",
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1717156521780'] = function(block) {
  let code = "MOTOrigid16(20,20,20,75,65,65,65,65,20,20,20,75,65,65,65,65)\nMOTOsetspeed(24)\nMOTOmove19(60,16,190,95,120,55,154,95,136,187,10,105,137,145,106,105,0,0,100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(60,16,190,95,120,55,154,93,136,187,10,105,137,145,106,107,0,0,100)\nMOTOwait()\nMOTOsetspeed(50)\nMOTOmove19(60,16,190,98,102,77,115,100,136,187,10,99,99,123,86,98,0,0,100)\nMOTOwait()\nMOTOrigid16(20,20,20,75,65,65,65,65,20,20,20,75,65,65,65,65)\nMOTOsetspeed(24)\nMOTOmove19(60,16,190,95,120,55,154,95,136,187,10,105,137,145,106,105,0,0,100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(60,16,190,95,120,55,154,93,136,187,10,105,137,145,106,107,0,0,100)\nMOTOwait()\nMOTOsetspeed(50)\nMOTOmove19(60,16,190,98,102,77,115,100,136,187,10,99,99,123,86,98,0,0,100)\nMOTOwait()\n";
  return code;
}

Blockly.Python['1717156521780'] = function(block) {
  let code = "base_action.action('抱箱右转90度')\n";
  return code;
}

