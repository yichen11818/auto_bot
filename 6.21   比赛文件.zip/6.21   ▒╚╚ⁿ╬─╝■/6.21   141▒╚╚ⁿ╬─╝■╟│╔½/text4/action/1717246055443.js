Blockly.Blocks['1717246055443'] = {
  init: function() {
    this.jsonInit({
      "type": "1717246055443",
      "message0": "微左侧移",
      "previousStatement": null,
      "nextStatement": null,
      "colour": "#EDC611",
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1717246055443'] = function(block) {
  let code = "MOTOrigid16(40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40)\nMOTOsetspeed(30)\nMOTOmove19(60,15,190,100,85,55,124,100,132,187,10,100,115,145,76,100,0,0,100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(60,15,190,100,85,55,124,100,132,187,10,110,115,145,76,100,0,0,100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(60,15,190,100,85,55,124,100,132,187,10,100,115,145,76,100,0,0,100)\nMOTOwait()\n";
  return code;
}

Blockly.Python['1717246055443'] = function(block) {
  let code = "base_action.action('微左侧移')\n";
  return code;
}

