Blockly.Blocks['1717747622323'] = {
  init: function() {
    this.jsonInit({
      "type": "1717747622323",
      "message0": "Fast_Forward2s",
      "previousStatement": null,
      "nextStatement": null,
      "colour": "#EDC611",
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1717747622323'] = function(block) {
  let code = "MOTOrigid16(25,25,10,55,65,90,80,50,25,25,10,55,65,90,80,50)\nMOTOsetspeed(45)\nMOTOmove19(80,30,100,98,93,54,122,90,120,170,100,102,107,146,75,95,0,0,100)\nMOTOwait()\nMOTOsetspeed(75)\nMOTOmove19(80,30,80,98,115,85,115,100,120,170,80,102,109,134,89,95,0,0,100)\nMOTOwait()\nMOTOsetspeed(80)\nMOTOmove19(80,30,80,98,116,74,121,100,120,170,80,102,110,137,89,105,0,0,100)\nMOTOwait()\nMOTOsetspeed(80)\nMOTOmove19(80,30,80,98,110,61,126,105,120,170,80,102,100,137,85,105,0,0,100)\nMOTOwait()\nMOTOsetspeed(75)\nMOTOmove19(80,30,120,98,91,66,111,105,120,170,120,102,85,110,88,105,0,0,100)\nMOTOwait()\nMOTOsetspeed(80)\nMOTOmove19(80,30,120,98,86,63,111,95,120,170,120,102,85,126,76,100,0,0,100)\nMOTOwait()\nMOTOsetspeed(80)\nMOTOmove19(80,30,120,98,100,73,106,95,120,170,120,102,90,139,74,95,0,0,100)\nMOTOwait()\nMOTOsetspeed(75)\nMOTOmove19(80,30,80,98,115,85,113,97,120,170,80,102,109,134,89,95,0,0,100)\nMOTOwait()\nMOTOsetspeed(80)\nMOTOmove19(80,30,80,98,110,74,121,100,120,170,80,102,110,137,89,95,0,0,100)\nMOTOwait()\nMOTOsetspeed(80)\nMOTOmove19(80,30,80,98,116,61,126,100,120,170,80,102,100,127,94,100,0,0,100)\nMOTOwait()\nMOTOsetspeed(75)\nMOTOmove19(80,30,120,98,91,66,111,105,120,170,120,102,85,110,88,105,0,0,100)\nMOTOwait()\nMOTOsetspeed(80)\nMOTOmove19(80,30,120,98,86,63,111,95,120,170,120,102,85,126,76,100,0,0,100)\nMOTOwait()\nMOTOsetspeed(80)\nMOTOmove19(80,30,120,98,100,73,106,95,120,170,120,102,90,139,74,95,0,0,100)\nMOTOwait()\nMOTOsetspeed(65)\nMOTOmove19(80,30,80,98,110,60,125,100,120,170,80,102,90,139,75,95,0,0,100)\nMOTOwait()\nMOTOsetspeed(45)\nMOTOmove19(80,30,100,100,93,55,124,100,120,170,100,100,107,145,76,100,0,0,100)\nMOTOwait()\n";
  return code;
}

Blockly.Python['1717747622323'] = function(block) {
  let code = "base_action.action('Fast_Forward2s')\n";
  return code;
}

