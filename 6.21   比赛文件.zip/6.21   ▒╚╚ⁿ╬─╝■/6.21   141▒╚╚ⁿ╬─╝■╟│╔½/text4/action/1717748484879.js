Blockly.Blocks['1717748484879'] = {
  init: function() {
    this.jsonInit({
      "type": "1717748484879",
      "message0": "move_right1s",
      "previousStatement": null,
      "nextStatement": null,
      "colour": "#EDC611",
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1717748484879'] = function(block) {
  let code = "MOTOrigid16(40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40)\nMOTOsetspeed(60)\nMOTOmove19(80,45,100,65,95,55,127,96,120,167,100,105,105,145,73,105,0,0,100)\nMOTOwait()\nMOTOrigid16(40,40,40,70,70,70,70,70,40,40,40,70,70,70,70,70)\nMOTOsetspeed(80)\nMOTOmove19(80,30,96,105,95,55,127,100,120,167,100,100,105,145,73,100,0,0,100)\nMOTOwait()\nDelayMs(50)\n";
  return code;
}

Blockly.Python['1717748484879'] = function(block) {
  let code = "base_action.action('move_right1s')\n";
  return code;
}

