Blockly.Blocks['1717900838622'] = {
  init: function() {
    this.jsonInit({
      "type": "1717900838622",
      "message0": "2",
      "previousStatement": null,
      "nextStatement": null,
      "colour": "#EDC611",
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1717900838622'] = function(block) {
  let code = "MOTOrigid16(40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40)\nMOTOsetspeed(30)\nMOTOmove19(64,12,190,102,85,55,124,100,132,190,13,98,115,145,76,100,0,0,100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(64,12,190,80,85,55,124,100,132,190,13,100,115,145,76,100,0,0,100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(64,12,190,102,85,55,124,100,132,190,13,98,115,145,76,100,0,0,100)\nMOTOwait()\n";
  return code;
}

Blockly.Python['1717900838622'] = function(block) {
  let code = "base_action.action('2')\n";
  return code;
}

