Blockly.Blocks['1718202807325'] = {
  init: function() {
    this.jsonInit({
      "type": "1718202807325",
      "message0": "BoxLeft1gai2",
      "previousStatement": null,
      "nextStatement": null,
      "colour": '#C643F1',
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1718202807325'] = function(block) {
  let code = "MOTOsetspeed(30)\nMOTOrigid16(40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,0,0,0)\nMOTOsetspeed(30)\nMOTOmove19(64, 12, 190, 102, 85, 55, 124, 100, 132, 190, 13, 98, 115, 145, 76, 100, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(50)\nMOTOmove19(64, 12, 190, 100, 85, 55, 124, 100, 132, 190, 13, 120, 115, 145, 76, 100, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(50)\nMOTOmove19(64, 12, 190, 102, 85, 55, 124, 100, 132, 190, 13, 98, 115, 145, 76, 100, 0, 0, 100)\nMOTOwait()\n";
  return code;
}

Blockly.Python['1718202807325'] = function(block) {
  let code = "base_action.action('BoxLeft1gai2')\n";
  return code;
}

