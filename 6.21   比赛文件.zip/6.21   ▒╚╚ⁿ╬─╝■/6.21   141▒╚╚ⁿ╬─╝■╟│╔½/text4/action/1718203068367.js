Blockly.Blocks['1718203068367'] = {
  init: function() {
    this.jsonInit({
      "type": "1718203068367",
      "message0": "move_right1sgai",
      "previousStatement": null,
      "nextStatement": null,
      "colour": '#C643F1',
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1718203068367'] = function(block) {
  let code = "MOTOsetspeed(30)\nMOTOrigid16(40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,0,0,0)\nMOTOsetspeed(60)\nMOTOmove19(80, 45, 100, 65, 95, 55, 127, 100, 120, 167, 100, 100, 105, 145, 73, 107, 0, 0, 100)\nMOTOwait()\nMOTOrigid16(40,40,40,70,70,70,70,70,40,40,40,70,70,70,70,70,0,0,0)\nMOTOsetspeed(80)\nMOTOmove19(80, 30, 96, 105, 95, 55, 127, 100, 120, 167, 100, 100, 105, 145, 73, 100, 0, 0, 100)\nMOTOwait()\nDelayMs(50)\n";
  return code;
}

Blockly.Python['1718203068367'] = function(block) {
  let code = "base_action.action('move_right1sgai')\n";
  return code;
}

