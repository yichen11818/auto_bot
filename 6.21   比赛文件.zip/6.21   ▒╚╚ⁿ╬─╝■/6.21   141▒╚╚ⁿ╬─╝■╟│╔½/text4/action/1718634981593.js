Blockly.Blocks['1718634981593'] = {
  init: function() {
    this.jsonInit({
      "type": "1718634981593",
      "message0": "Fast_Forward2sgai4",
      "previousStatement": null,
      "nextStatement": null,
      "colour": '#C643F1',
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1718634981593'] = function(block) {
  let code = "MOTOsetspeed(30)\nMOTOrigid16(25,25,10,55,65,90,80,50,25,25,10,55,65,90,80,50,0,0,0)\nMOTOsetspeed(45)\nMOTOmove19(80, 30, 100, 98, 95, 54, 122, 90, 120, 170, 100, 102, 105, 146, 75, 95, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(75)\nMOTOmove19(80, 30, 80, 98, 120, 85, 117, 100, 120, 170, 80, 102, 109, 134, 89, 95, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(80)\nMOTOmove19(80, 30, 80, 98, 116, 70, 125, 100, 120, 170, 80, 102, 110, 137, 89, 105, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(80)\nMOTOmove19(80, 30, 80, 98, 110, 61, 126, 105, 120, 170, 80, 102, 100, 137, 85, 105, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(75)\nMOTOmove19(80, 30, 120, 98, 91, 66, 111, 105, 120, 170, 120, 102, 85, 110, 88, 105, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(80)\nMOTOmove19(80, 30, 120, 98, 86, 63, 111, 95, 120, 170, 120, 102, 90, 130, 76, 100, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(80)\nMOTOmove19(80, 30, 120, 98, 103, 73, 106, 95, 120, 170, 120, 102, 90, 139, 74, 95, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(75)\nMOTOmove19(80, 30, 80, 98, 120, 85, 117, 97, 120, 170, 80, 102, 109, 134, 89, 95, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(80)\nMOTOmove19(80, 30, 80, 98, 116, 61, 135, 100, 120, 170, 80, 102, 100, 127, 94, 100, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(75)\nMOTOmove19(80, 30, 120, 98, 91, 66, 111, 105, 120, 170, 120, 102, 85, 110, 88, 105, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(80)\nMOTOmove19(80, 30, 120, 98, 86, 63, 111, 95, 120, 170, 120, 102, 95, 135, 76, 100, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(80)\nMOTOmove19(80, 30, 100, 100, 105, 60, 125, 95, 120, 170, 100, 102, 95, 139, 74, 95, 0, 0, 100)\nMOTOwait()\nMOTOsetspeed(45)\nMOTOmove19(80, 30, 100, 100, 95, 55, 124, 100, 120, 170, 100, 100, 105, 145, 76, 100, 0, 0, 100)\nMOTOwait()\n";
  return code;
}

Blockly.Python['1718634981593'] = function(block) {
  let code = "base_action.action('Fast_Forward2sgai4')\n";
  return code;
}

