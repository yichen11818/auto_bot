Blockly.Blocks['1720714836373'] = {
  init: function() {
    this.jsonInit({
      "type": "1720714836373",
      "message0": "Box_Left3",
      "previousStatement": null,
      "nextStatement": null,
      "colour": "#EDC611",
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1720714836373'] = function(block) {
  let code = "MOTOrigid16(40,40,40,70,70,70,70,70,40,40,40,70,70,70,70,70)\nMOTOsetspeed(30)\nMOTOmove19(62,12,190,100,90,55,127,93,135,190,13,135,110,145,73,100,0,0,100)\nMOTOwait()\nMOTOrigid16(40,40,40,70,70,70,70,70,40,40,40,70,70,70,70,70)\nMOTOsetspeed(80)\nMOTOmove19(62,12,190,100,90,55,127,100,135,190,13,95,110,145,73,100,0,0,100)\nMOTOwait()\nDelayMs(260)\nMOTOrigid16(40,40,40,70,70,70,70,70,40,40,40,70,70,70,70,70)\nMOTOsetspeed(30)\nMOTOmove19(62,12,190,100,90,55,127,93,135,190,13,135,110,145,73,100,0,0,100)\nMOTOwait()\nMOTOrigid16(40,40,40,70,70,70,70,70,40,40,40,70,70,70,70,70)\nMOTOsetspeed(80)\nMOTOmove19(62,12,190,100,90,55,127,100,135,190,13,95,110,145,73,100,0,0,100)\nMOTOwait()\nDelayMs(260)\nMOTOrigid16(40,40,40,70,70,70,70,70,40,40,40,70,70,70,70,70)\nMOTOsetspeed(30)\nMOTOmove19(62,12,190,100,90,55,127,93,135,190,13,135,110,145,73,100,0,0,100)\nMOTOwait()\nMOTOrigid16(40,40,40,70,70,70,70,70,40,40,40,70,70,70,70,70)\nMOTOsetspeed(80)\nMOTOmove19(62,12,190,100,90,55,127,100,135,190,13,95,110,145,73,100,0,0,100)\nMOTOwait()\nDelayMs(260)\nMOTOrigid16(40,40,40,70,70,70,70,70,40,40,40,70,70,70,70,70)\nMOTOsetspeed(30)\nMOTOmove19(62,12,190,100,90,55,127,93,135,190,13,135,110,145,73,100,0,0,100)\nMOTOwait()\nMOTOrigid16(40,40,40,70,70,70,70,70,40,40,40,70,70,70,70,70)\nMOTOsetspeed(80)\nMOTOmove19(62,12,190,100,90,55,127,100,135,190,13,95,110,145,73,100,0,0,100)\nMOTOwait()\nDelayMs(260)\nMOTOrigid16(25,25,10,55,65,90,80,50,25,25,10,55,65,90,80,50)\n";
  return code;
}

Blockly.Python['1720714836373'] = function(block) {
  let code = "base_action.action('Box_Left3')\n";
  return code;
}

