Blockly.Blocks['1676271852841'] = {
  init: function() {
    this.jsonInit({
      "type": "1676271852841",
      "message0": "抱箱左移1",
      "previousStatement": null,
      "nextStatement": null,
      "colour": "#EDC611",
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1676271852841'] = function(block) {
  let code = "MOTOrigid16(20,20,20,65,85,95,85,35,20,20,20,65,55,55,55,35)\nMOTOsetspeed(65)\nMOTOmove19(65,10,149,85,112,90,115,90,140,190,50,110,107,146,70,100,128,71,100)\nMOTOwait()\nDelayMs(50)\nMOTOsetspeed(75)\nMOTOmove19(65,10,149,95,93,53,131,105,140,190,50,120,116,160,68,130,128,71,100)\nMOTOwait()\nMOTOsetspeed(65)\nMOTOmove19(65,10,149,100,93,54,134,98,140,190,50,103,107,146,76,105,128,71,100)\nMOTOwait()\nMOTOsetspeed(20)\nMOTOmove19(65,10,149,100,93,55,134,95,140,190,50,100,107,145,76,105,128,71,100)\nMOTOwait()\nDelayMs(50)\nMOTOsetspeed(20)\nMOTOmove19(65,10,149,100,93,55,134,100,140,190,50,100,107,145,76,100,128,71,100)\nMOTOwait()\n";
  return code;
}

