Blockly.Blocks['1676272887706'] = {
  init: function() {
    this.jsonInit({
      "type": "1676272887706",
      "message0": "放下10cm方块",
      "previousStatement": null,
      "nextStatement": null,
      "colour": "#EDC611",
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1676272887706'] = function(block) {
  let code = "MOTOrigid16(60,60,60,30,60,60,60,30,60,60,60,30,60,60,60,30)\nMOTOsetspeed(30)\nMOTOmove19(100,185,100,98,93,55,124,98,100,15,100,102,107,145,76,102,128,71,100)\nMOTOwait()\nMOTOsetspeed(20)\nMOTOmove19(100,185,100,102,142,145,77,98,100,15,100,98,58,55,123,102,128,71,100)\nMOTOwait()\nMOTOrigid16(100,100,100,100,80,80,80,30,100,100,100,100,80,80,80,30)\nMOTOsetspeed(14)\nMOTOmove19(100,185,10,70,128,145,75,70,100,15,190,130,72,55,125,130,128,71,100)\nMOTOwait()\nMOTOsetspeed(14)\nMOTOmove19(90,185,10,55,158,140,55,60,110,15,190,145,42,60,145,140,128,71,100)\nMOTOwait()\nMOTOsetspeed(14)\nMOTOmove19(110,155,10,65,138,150,55,70,90,45,190,135,62,50,145,130,128,71,100)\nMOTOwait()\nMOTOsetspeed(14)\nMOTOmove19(110,155,10,70,128,145,75,70,90,45,190,130,72,55,125,130,128,71,100)\nMOTOwait()\nDelayMs(500)\nMOTOrigid16(100,100,100,100,80,80,80,30,100,100,100,100,80,80,80,30)\nMOTOsetspeed(30)\nMOTOmove19(80,165,100,98,142,145,77,98,120,35,100,102,58,55,123,102,128,71,100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(100,185,100,98,122,40,152,98,100,15,100,102,78,160,48,102,128,71,100)\nMOTOwait()\nDelayMs(100)\nMOTOsetspeed(30)\nMOTOmove19(80,30,100,100,93,55,124,100,120,170,100,100,107,145,76,100,128,71,100)\nMOTOwait()\n";
  return code;
}

