Blockly.Blocks['1680500322955'] = {
  init: function() {
    this.jsonInit({
      "type": "1680500322955",
      "message0": "前进",
      "previousStatement": null,
      "nextStatement": null,
      "colour": "#EDC611",
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1680500322955'] = function(block) {
  let code = "MOTOrigid16(30,30,30,65,75,80,75,65,30,30,30,65,75,80,75,65)\nMOTOsetspeed(6)\nMOTOmove19(65,20,149,90,91,48,134,88,140,180,50,94,109,146,71,89,128,71,100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(65,20,149,86,123,95,115,90,140,180,50,94,109,146,71,87,128,71,100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(65,20,149,86,121,37,161,88,140,180,50,94,109,146,72,89,128,71,100)\nMOTOwait()\nMOTOsetspeed(10)\nMOTOmove19(65,20,149,107,98,56,129,111,140,180,50,112,131,155,88,110,128,71,100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(65,20,149,106,93,54,128,113,140,180,50,114,77,105,85,110,128,71,100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(65,20,149,106,91,54,128,111,140,180,50,114,89,163,39,112,128,71,100)\nMOTOwait()\nMOTOsetspeed(10)\nMOTOmove19(65,20,149,88,69,45,112,90,140,180,50,93,102,144,71,89,128,71,100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(65,20,149,86,123,95,115,90,140,180,50,94,107,146,72,87,128,71,100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(65,20,149,100,91,55,129,100,140,180,50,100,109,145,71,100,128,71,100)\nMOTOwait()\n";
  return code;
}

