Blockly.Blocks['1717423167815'] = {
  init: function() {
    this.jsonInit({
      "type": "1717423167815",
      "message0": "10s登台1(1)",
      "previousStatement": null,
      "nextStatement": null,
      "colour": '#C643F1',
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.Lua['1717423167815'] = function(block) {
  let code = "MOTOsetspeed(30)\nMOTOrigid16(40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,0,0,0)\nMOTOsetspeed(50)\nMOTOmove19(100, 100, 100, 90, 91, 48, 129, 88, 100, 100, 100, 92, 107, 146, 76, 88, 128, 71, 100)\nMOTOwait()\nDelayMs(300)\nMOTOsetspeed(150)\nMOTOmove19(100, 100, 100, 85, 115, 95, 102, 90, 100, 100, 100, 93, 102, 145, 74, 87, 128, 71, 100)\nMOTOwait()\nDelayMs(200)\nMOTOsetspeed(150)\nMOTOmove19(100, 100, 100, 94, 140, 146, 77, 86, 100, 100, 100, 103, 102, 145, 74, 88, 128, 71, 100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(100, 100, 100, 90, 115, 145, 47, 85, 100, 100, 100, 142, 101, 148, 75, 134, 128, 71, 100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(100, 100, 100, 90, 115, 145, 47, 85, 100, 100, 100, 120, 101, 143, 75, 121, 128, 71, 100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(100, 100, 100, 90, 115, 101, 94, 92, 100, 100, 100, 120, 113, 176, 56, 77, 128, 71, 100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(100, 100, 100, 90, 115, 140, 58, 110, 100, 100, 100, 126, 113, 177, 55, 86, 128, 71, 100)\nMOTOwait()\nMOTOsetspeed(20)\nMOTOmove19(80, 30, 100, 100, 93, 55, 124, 100, 120, 170, 100, 100, 107, 145, 76, 100, 128, 71, 100)\nMOTOwait()\n\n\n-- 2\nMOTOsetspeed(25)\nMOTOmove19(94, 79, 100, 85, 106, 79, 113, 80, 106, 100, 100, 94, 107, 145, 76, 88, 128, 71, 100)\nMOTOwait()\nMOTOrigid16(25,25,25,60,60,60,60,60,25,25,25,90,90,90,90,90,0,0,0)\n\n\n-- 左腿上台阶\nMOTOsetspeed(15)\nMOTOmove19(97, 105, 100, 85, 132, 127, 85, 89, 103, 100, 100, 94, 107, 145, 76, 88, 128, 71, 100)\nMOTOwait()\nMOTOrigid16(25,25,25,60,60,60,60,60,25,25,25,90,90,90,90,90,0,0,0)\n\n\n-- 1\nMOTOsetspeed(35)\nMOTOmove19(97, 150, 100, 85, 160, 50, 180, 95, 100, 100, 100, 95, 85, 100, 99, 90, 128, 71, 100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(100, 150, 100, 85, 160, 50, 180, 95, 100, 100, 100, 99, 85, 100, 99, 90, 128, 71, 100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(100, 150, 100, 100, 160, 78, 155, 100, 100, 100, 100, 100, 136, 150, 108, 99, 128, 71, 100)\nMOTOwait()\nMOTOrigid16(25,25,25,90,100,100,100,90,25,25,25,90,90,90,90,90,0,0,0)\nMOTOsetspeed(30)\nMOTOmove19(99, 10, 159, 107, 160, 91, 118, 111, 100, 190, 43, 107, 130, 190, 48, 104, 128, 71, 100)\nMOTOwait()\nMOTOsetspeed(150)\nMOTOmove19(75, 10, 158, 107, 160, 91, 118, 111, 130, 190, 42, 107, 130, 190, 48, 104, 128, 71, 100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(75, 10, 158, 107, 160, 91, 118, 111, 130, 190, 42, 107, 130, 190, 48, 104, 128, 71, 100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(75, 10, 159, 107, 160, 91, 118, 111, 130, 190, 42, 110, 157, 169, 136, 99, 128, 71, 100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(75, 10, 159, 107, 160, 91, 118, 111, 130, 190, 42, 108, 41, 87, 109, 101, 128, 71, 100)\nMOTOwait()\nMOTOsetspeed(10)\nMOTOmove19(75, 10, 159, 106, 142, 117, 99, 111, 130, 190, 42, 107, 62, 88, 98, 110, 128, 71, 100)\nMOTOwait()\nMOTOsetspeed(30)\nMOTOmove19(75, 10, 159, 101, 140, 120, 97, 102, 130, 190, 42, 102, 62, 81, 106, 100, 128, 71, 100)\nMOTOwait()\nMOTOsetspeed(10)\nMOTOmove19(65, 15, 149, 100, 104, 132, 70, 100, 140, 180, 50, 100, 93, 69, 130, 100, 128, 78, 100)\nMOTOwait()\nMOTOsetspeed(20)\nMOTOmove19(65, 15, 149, 100, 90, 55, 127, 100, 140, 180, 50, 100, 110, 145, 73, 100, 127, 78, 100)\nMOTOwait()\n";
  return code;
}

Blockly.Python['1717423167815'] = function(block) {
  let code = "robot.leju_action('10s登台1(1)')\n";
  return code;
}

